from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
#from .models import userdetails as User
# Create your views here.
from django.http import HttpResponse
from . import templates
# from .models import tb1_auth
from django.contrib.auth.models import User, auth
from  django.contrib.auth import authenticate,login,logout

def second_page(request):
    return HttpResponse('<body><center><h1>this is from second_app akhil page1</h1></center></body>')


def login(request):

    # if request.method=='POST':
    #     username=request.POST.get('username')
    #     password=request.POST.get('password')
    #     user=authenticate(request,username=username,password=password)
    #
    #     # if user is not None:
    # return render(request,'second_app/main.html')
    return render(request, 'second_app/logintoday.html')



def signin(request):
    if request.method == 'POST':
        fname = request.POST['first_name']
        lname = request.POST['last_name']
        uname = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        user = User.objects.create_user(username=uname,password=password, email=email, first_name=fname,
                                             last_name=lname)
        user.save();
        print('user created')
        return render(request, 'second_app/main.html')
    else:

        return render(request, 'second_app/signup.html')


def about(request):
    return render(request, 'second_app/about.html')


def mainpage(request):
    return render(request, 'second_app/main.html')
def travelpage(request):
    return render(request,'second_app/travel.html')
def tourismpage(request):
    return render(request,'second_app/tourism.html')
def hospitalitypage(request):
    return render(request,'second_app/hospitality.html')
def paymentpage(request):
    return render(request,'second_app/payment.html')
def graphs(request):
    return render(request,'second_app/graph.html')
def feedback(request):
    return render(request,'second_app/feedback.html')
def bookdetails(request):
    return render(request, 'second_app/bookhotel.html')
def confirm(request):
    return render(request, 'second_app/confirm.html')
