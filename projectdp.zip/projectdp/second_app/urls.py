from django.urls import path
from . import views

from django.urls import path,include

urlpatterns = [path('page1/', views.second_page, name='second_app'),
               path('login/',views.login,name='login'),
               path('signin/',views.signin,name='signin'),
               path('about/', views.about, name='about'),
               path('main/', views.mainpage, name='main'),
               path('travel/', views.travelpage, name='travel'),
               path('tourism/', views.tourismpage, name='tourism'),
               path('hospitality/', views.hospitalitypage, name='hospitality'),
               path('payment/', views.paymentpage, name='payment'),
               path('signin/signin', views.signin, name='signin'),
               path('login/register', views.mainpage),
               path('graphs/', views.graphs, name='graphs'),
               path('bookdetails/',views.bookdetails,name='bookdetails'),
               path('feedback/', views.feedback, name='feedback'),
               path('login/login',views.login,name='login'),
                path('confirm/',views.confirm,name='confirm'),
               ]
