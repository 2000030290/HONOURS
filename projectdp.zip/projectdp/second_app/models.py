from django.db import models

from django.contrib.auth.models import AbstractBaseUser, UserManager

class User(AbstractBaseUser):
    ...
    objects =  UserManager()

# Create your models here.
from django.db import models
class userdetails(models.Model):
    fname=models.CharField(max_length=50,default='')
    lname = models.CharField(max_length=50, default='')
    username = models.CharField(max_length=50, default='')
    email=models.EmailField(default='')
    password=models.CharField(max_length=50,default='')

class feedback(models.Model):
    fname:models.CharField(max_length=50,default='',primary_key=True)
    lname:models.CharField(max_length=50,default='')
    subject:models.CharField(max_length=500,default='')
#     def __str__(self):
#         return self.email
#
#     tth_ob=models.Manager()
